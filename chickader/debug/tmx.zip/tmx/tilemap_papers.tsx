<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.4" tiledversion="1.4.1" name="tilemap_papers" tilewidth="16" tileheight="16" tilecount="1" columns="1">
 <image source="tilemap_papers.png" width="16" height="16"/>
 <tile id="0">
  <properties>
   <property name="file_name" value="images/lv_paper_01_01.png"/>
  </properties>
 </tile>
 <tile id="1">
  <properties>
   <property name="file_name" value="images/lv_paper_01_02.png"/>
  </properties>
 </tile>
 <tile id="2">
  <properties>
   <property name="file_name" value="images/lv_paper_01_03.png"/>
  </properties>
 </tile>
 <tile id="3">
  <properties>
   <property name="file_name" value="images/lv_paper_01_04.png"/>
  </properties>
 </tile>
 <tile id="4">
  <properties>
   <property name="file_name" value="images/lv_paper_01_05.png"/>
  </properties>
 </tile>
 <tile id="5">
  <properties>
   <property name="file_name" value="images/lv_paper_01_06.png"/>
  </properties>
 </tile>
 <tile id="6">
  <properties>
   <property name="file_name" value="images/lv_paper_02_01.png"/>
  </properties>
 </tile>
 <tile id="7">
  <properties>
   <property name="file_name" value="images/lv_paper_02_02.png"/>
  </properties>
 </tile>
 <tile id="8">
  <properties>
   <property name="file_name" value="images/lv_paper_02_03.png"/>
  </properties>
 </tile>
 <tile id="9">
  <properties>
   <property name="file_name" value="images/lv_paper_02_04.png"/>
  </properties>
 </tile>
 <tile id="10">
  <properties>
   <property name="file_name" value="images/lv_paper_03_01.png"/>
  </properties>
 </tile>
 <tile id="11">
  <properties>
   <property name="file_name" value="images/lv_paper_03_02.png"/>
  </properties>
 </tile>
 <tile id="12">
  <properties>
   <property name="file_name" value="images/lv_paper_03_03.png"/>
  </properties>
 </tile>
 <tile id="13">
  <properties>
   <property name="file_name" value="images/lv_paper_03_04.png"/>
  </properties>
 </tile>
 <tile id="14">
  <properties>
   <property name="file_name" value="images/lv_paper_04_01.png"/>
  </properties>
 </tile>
 <tile id="15">
  <properties>
   <property name="file_name" value="images/lv_paper_04_02.png"/>
  </properties>
 </tile>
 <tile id="16">
  <properties>
   <property name="file_name" value="images/lv_paper_04_03.png"/>
  </properties>
 </tile>
 <tile id="17">
  <properties>
   <property name="file_name" value="images/lv_paper_04_04.png"/>
  </properties>
 </tile>
</tileset>
