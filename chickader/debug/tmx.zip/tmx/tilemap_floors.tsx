<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.6.0" name="tilemap_floors" tilewidth="16" tileheight="16" tilecount="5" columns="5">
 <image source="tilemap_floors.png" width="80" height="16"/>
 <tile id="0">
  <properties>
   <property name="file_name" value="images/lv_floor_01.png"/>
  </properties>
 </tile>
 <tile id="1">
  <properties>
   <property name="file_name" value="images/lv_floor_02.png"/>
  </properties>
 </tile>
</tileset>
