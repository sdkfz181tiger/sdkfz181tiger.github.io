<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.6.0" name="tilemap_walls" tilewidth="16" tileheight="16" tilecount="2" columns="2">
 <image source="tilemap_walls.png" width="32" height="16"/>
 <tile id="0">
  <properties>
   <property name="file_name" value="images/lv_wall_01.png"/>
  </properties>
 </tile>
 <tile id="1">
  <properties>
   <property name="file_name" value="images/lv_wall_02.png"/>
  </properties>
 </tile>
</tileset>
