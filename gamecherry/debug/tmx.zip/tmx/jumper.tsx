<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.1" name="jumper" tilewidth="28" tileheight="28" tilecount="5" columns="5">
 <image source="jumper.png" width="140" height="28"/>
</tileset>
