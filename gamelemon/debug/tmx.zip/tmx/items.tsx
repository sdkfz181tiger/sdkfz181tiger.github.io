<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.1" name="items" tilewidth="28" tileheight="28" tilecount="7" columns="7">
 <image source="items.png" width="196" height="28"/>
 <tile id="0">
  <properties>
   <property name="name" value="noname"/>
  </properties>
 </tile>
 <tile id="1">
  <properties>
   <property name="name" value="radish"/>
  </properties>
 </tile>
 <tile id="2">
  <properties>
   <property name="name" value="carrot"/>
  </properties>
 </tile>
 <tile id="3">
  <properties>
   <property name="name" value="tomato"/>
  </properties>
 </tile>
 <tile id="4">
  <properties>
   <property name="name" value="cabagge"/>
  </properties>
 </tile>
 <tile id="5">
  <properties>
   <property name="name" value="corn"/>
  </properties>
 </tile>
 <tile id="6">
  <properties>
   <property name="name" value="eggplant"/>
  </properties>
 </tile>
</tileset>
