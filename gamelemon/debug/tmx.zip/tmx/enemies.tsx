<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.1" name="enemies" tilewidth="28" tileheight="28" tilecount="18" columns="9">
 <image source="enemies.png" width="252" height="56"/>
 <tile id="0">
  <properties>
   <property name="name" value="noname"/>
  </properties>
 </tile>
 <tile id="1">
  <properties>
   <property name="name" value="bozu"/>
  </properties>
 </tile>
 <tile id="2">
  <properties>
   <property name="name" value="osho"/>
  </properties>
 </tile>
 <tile id="3">
  <properties>
   <property name="name" value="bushi"/>
  </properties>
 </tile>
 <tile id="4">
  <properties>
   <property name="name" value="musha"/>
  </properties>
 </tile>
 <tile id="5">
  <properties>
   <property name="name" value="ninja"/>
  </properties>
 </tile>
 <tile id="6">
  <properties>
   <property name="name" value="oni_r"/>
  </properties>
 </tile>
 <tile id="7">
  <properties>
   <property name="name" value="oni_b"/>
  </properties>
 </tile>
 <tile id="8">
  <properties>
   <property name="name" value="shishi"/>
  </properties>
 </tile>
 <tile id="9">
  <properties>
   <property name="name" value="tengu"/>
  </properties>
 </tile>
 <tile id="10">
  <properties>
   <property name="name" value="karasu"/>
  </properties>
 </tile>
 <tile id="11">
  <properties>
   <property name="name" value="slime_k_g"/>
  </properties>
 </tile>
 <tile id="12">
  <properties>
   <property name="name" value="musume"/>
  </properties>
 </tile>
 <tile id="13">
  <properties>
   <property name="name" value="yuki"/>
  </properties>
 </tile>
 <tile id="14">
  <properties>
   <property name="name" value="dokuro"/>
  </properties>
 </tile>
 <tile id="15">
  <properties>
   <property name="name" value="doron"/>
  </properties>
 </tile>
 <tile id="16">
  <properties>
   <property name="name" value="niwa"/>
  </properties>
 </tile>
 <tile id="17">
  <properties>
   <property name="name" value="hiyo"/>
  </properties>
 </tile>
</tileset>
