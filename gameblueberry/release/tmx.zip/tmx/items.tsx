<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.1" name="items" tilewidth="28" tileheight="28" tilecount="9" columns="9">
 <image source="items.png" width="252" height="28"/>
 <tile id="0">
  <properties>
   <property name="name" value="xx.png"/>
  </properties>
 </tile>
 <tile id="1">
  <properties>
   <property name="name" value="i_apple.png"/>
  </properties>
 </tile>
 <tile id="2">
  <properties>
   <property name="name" value="i_blueberry.png"/>
  </properties>
 </tile>
 <tile id="3">
  <properties>
   <property name="name" value="i_cherry.png"/>
  </properties>
 </tile>
 <tile id="4">
  <properties>
   <property name="name" value="i_orange.png"/>
  </properties>
 </tile>
 <tile id="5">
  <properties>
   <property name="name" value="i_strawberry.png"/>
  </properties>
 </tile>
 <tile id="6">
  <properties>
   <property name="name" value="i_lemon.png"/>
  </properties>
 </tile>
 <tile id="7">
  <properties>
   <property name="name" value="i_peach.png"/>
  </properties>
 </tile>
 <tile id="8">
  <properties>
   <property name="name" value="i_banana.png"/>
  </properties>
 </tile>
</tileset>
