<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.1" name="enemies" tilewidth="28" tileheight="28" tilecount="18" columns="9">
 <image source="enemies.png" width="252" height="56"/>
</tileset>
