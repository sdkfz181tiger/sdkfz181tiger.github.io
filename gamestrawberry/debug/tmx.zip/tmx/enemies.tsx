<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.2" name="enemies" tilewidth="15" tileheight="15" tilecount="8" columns="8">
 <image source="enemies.png" width="120" height="15"/>
</tileset>
