<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.2" name="enemies" tilewidth="15" tileheight="15" tilecount="32" columns="8">
 <image source="enemies.png" width="120" height="60"/>
 <tile id="0" type="inv_01"/>
 <tile id="1" type="inv_02"/>
 <tile id="2" type="inv_03"/>
 <tile id="3" type="inv_04"/>
 <tile id="4" type="inv_05"/>
 <tile id="5" type="inv_06"/>
 <tile id="6" type="inv_07"/>
 <tile id="7" type="inv_08"/>
 <tile id="8" type="inv_01"/>
 <tile id="9" type="inv_02"/>
 <tile id="10" type="inv_03"/>
 <tile id="11" type="inv_04"/>
 <tile id="12" type="inv_05"/>
 <tile id="13" type="inv_06"/>
 <tile id="14" type="inv_07"/>
 <tile id="15" type="inv_08"/>
 <tile id="16" type="inv_01"/>
 <tile id="17" type="inv_02"/>
 <tile id="18" type="inv_03"/>
 <tile id="19" type="inv_04"/>
 <tile id="20" type="inv_05"/>
 <tile id="21" type="inv_06"/>
 <tile id="22" type="inv_07"/>
 <tile id="23" type="inv_08"/>
 <tile id="24" type="inv_01"/>
 <tile id="25" type="inv_02"/>
 <tile id="26" type="inv_03"/>
 <tile id="27" type="inv_04"/>
 <tile id="28" type="inv_05"/>
 <tile id="29" type="inv_06"/>
 <tile id="30" type="inv_07"/>
 <tile id="31" type="inv_08"/>
</tileset>
