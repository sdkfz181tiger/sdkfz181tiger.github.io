<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.2" name="enemies" tilewidth="15" tileheight="15" tilecount="8" columns="8">
 <image source="enemies.png" width="120" height="15"/>
 <tile id="0">
  <properties>
   <property name="frame_name" value="inv_01"/>
  </properties>
 </tile>
 <tile id="1">
  <properties>
   <property name="frame_name" value="inv_02"/>
  </properties>
 </tile>
 <tile id="2">
  <properties>
   <property name="frame_name" value="inv_03"/>
  </properties>
 </tile>
 <tile id="3">
  <properties>
   <property name="frame_name" value="inv_04"/>
  </properties>
 </tile>
 <tile id="4">
  <properties>
   <property name="frame_name" value="inv_05"/>
  </properties>
 </tile>
 <tile id="5">
  <properties>
   <property name="frame_name" value="inv_06"/>
  </properties>
 </tile>
 <tile id="6">
  <properties>
   <property name="frame_name" value="inv_07"/>
  </properties>
 </tile>
 <tile id="7">
  <properties>
   <property name="frame_name" value="inv_08"/>
  </properties>
 </tile>
</tileset>
