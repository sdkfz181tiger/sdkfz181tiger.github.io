<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.2" name="blocks" tilewidth="15" tileheight="15" tilecount="16" columns="16">
 <image source="blocks.png" width="240" height="15"/>
 <tile id="0" type="1"/>
 <tile id="1" type="2"/>
 <tile id="2" type="3"/>
 <tile id="3" type="4"/>
 <tile id="4" type="5"/>
 <tile id="5" type="6"/>
 <tile id="6" type="7"/>
 <tile id="7" type="8"/>
 <tile id="8" type="9"/>
 <tile id="9" type="10"/>
 <tile id="10" type="11"/>
 <tile id="11" type="12"/>
 <tile id="12" type="13"/>
 <tile id="13" type="14"/>
 <tile id="14" type="15"/>
 <tile id="15" type="16"/>
</tileset>
