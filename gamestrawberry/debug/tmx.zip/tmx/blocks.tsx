<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.2" name="blocks" tilewidth="15" tileheight="15" tilecount="8" columns="8">
 <image source="blocks.png" width="120" height="15"/>
 <tile id="0" type="tile_01"/>
 <tile id="1" type="tile_02"/>
 <tile id="2" type="tile_03"/>
 <tile id="3" type="tile_04"/>
 <tile id="4" type="tile_05"/>
 <tile id="5" type="tile_06"/>
 <tile id="6" type="tile_07"/>
 <tile id="7" type="tile_08"/>
</tileset>
