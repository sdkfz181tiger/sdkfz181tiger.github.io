<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.2" name="blocks" tilewidth="15" tileheight="15" tilecount="16" columns="16">
 <image source="blocks.png" width="240" height="15"/>
 <tile id="0" type="1"/>
 <tile id="1" type="images/blogk_28x28_02.png"/>
 <tile id="2" type="images/blogk_28x28_03.png"/>
 <tile id="3" type="images/blogk_28x28_04.png"/>
 <tile id="4" type="images/blogk_28x28_05.png"/>
 <tile id="5" type="images/blogk_28x28_06.png"/>
 <tile id="6" type="images/blogk_28x28_07.png"/>
 <tile id="7" type="images/blogk_28x28_08.png"/>
 <tile id="8" type="images/blogk_28x28_09.png"/>
 <tile id="9" type="images/blogk_28x28_10.png"/>
 <tile id="10" type="images/blogk_28x28_11.png"/>
 <tile id="11" type="images/blogk_28x28_12.png"/>
 <tile id="12" type="images/blogk_28x28_13.png"/>
 <tile id="13" type="images/blogk_28x28_14.png"/>
 <tile id="14" type="images/blogk_28x28_15.png"/>
 <tile id="15" type="images/blogk_28x28_16.png"/>
</tileset>
