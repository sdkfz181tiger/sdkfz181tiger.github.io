<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.2" name="coins" tilewidth="15" tileheight="15" tilecount="9" columns="9">
 <image source="coins.png" width="135" height="15"/>
 <tile id="0" type="coin_01"/>
 <tile id="1" type="coin_02"/>
 <tile id="2" type="coin_03"/>
 <tile id="3" type="coin_04"/>
 <tile id="4" type="coin_05"/>
 <tile id="5" type="coin_06"/>
 <tile id="6" type="coin_07"/>
 <tile id="7" type="coin_08"/>
 <tile id="8" type="coin_09"/>
</tileset>
